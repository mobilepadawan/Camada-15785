let objCotizar = ""                                             //Variable que usaremos con el OBJETO COTIZADOR
let areaResidencia = document.getElementById("areaResidencia")  //Combo RESIDENCIA
let tipoVivienda = document.getElementById("tipoVivienda")      //Combo TIPO DE VIVIENDA
let metros2 = document.getElementById("metros2")                //METROS CUADRADOS DE LA PROPIEDAD
let importeCuota = document.getElementById("importeCuota")      //LABEL QUE MUESTRA EL VALOR DE LA CUOTA
let btnCotizar = document.getElementById("btnCotizar")          //BOTON QUE DISPARA LA COTIZACON